#!/bin/bash

for file in ../cloudsLabeled_ply/*.ply
do
	filename=$(basename "$file")
	extension="${filename##*.}"
	filename="${filename%.*}"
	meshlabserver -i "$file" -o $filename.off -s alpha.mlx 
done

